package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class aut_product_page {
	WebDriver dr1;
	By txt = new By.ByClassName("product_label");
	
	public aut_product_page(WebDriver dr) {
		this.dr1 = dr;
	}
	public String get_text() {
		String act_text=dr1.findElement(txt).getText();
		return act_text;
	}
}