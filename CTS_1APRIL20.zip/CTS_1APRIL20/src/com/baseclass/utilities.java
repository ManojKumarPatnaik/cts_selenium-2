package com.baseclass;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class utilities {
	static int counter=1;
	WebDriver dr;

	public static WebDriver launch_browser(String browser,String url)
	{
		WebDriver dr = null;
		String ch_driver_path="chromedriver.exe";
		switch(browser)
		{
		case "chrome":
		System.setProperty("webdriver.chrome.driver","F:\\Eclipse Jar files\\chromedriver_win32\\chromedriver.exe");
		dr = new ChromeDriver();
		break;
		}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return dr;
	}
}

