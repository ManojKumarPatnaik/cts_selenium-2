package com.tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.baseclass.utilities;
import com.excel_util.excel_io_arr;
import com.pages.aut_login_page;
import com.pages.aut_product_page;

public class test_swaglabs extends excel_io_arr {
			WebDriver dr;
			aut_product_page homepage;
			aut_login_page loginpage;
			utilities util;
			String url = "https://www.saucedemo.com";
			aut_login_page lp ;
			aut_product_page pp;
		@BeforeClass
			public void Get_data()
			{
				Get_data();
			}
		@BeforeMethod
			public void launchBrowser()
			{
			dr=utilities.launch_browser("chrome", url);
			lp=new aut_login_page(dr);
			pp=new aut_product_page(dr);
			}
		@DataProvider(name="login_data")
		public String[][] get_login_data()
		{
			return testdata;
		}
		@Test(dataProvider = "login_data")
		public void login(String eid, String pwd, String exp_text)
		{
			lp.do_login(eid,pwd);
			String act_text = pp.get_text();
			SoftAssert sa = new SoftAssert();
			sa.assertEquals(exp_text, act_text);
			sa.assertAll();
		}
		@AfterMethod
			public void closebrowser()
			{
			dr.close();
			}
		}
		