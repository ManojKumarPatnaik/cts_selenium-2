package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;

public class TestScript {
	WebDriver dr;
	HomePage hp;
	LoginPage lp;
	
	@BeforeClass
	public void launchbrowser()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		hp = new HomePage(dr);
		lp = new LoginPage(dr);
	}
	
	@Test	
	public void logintest1() {
		hp.click_login_link();
		lp.do_login("yvsalekhya1@gmail.com","anusha");
		
	}	
}

